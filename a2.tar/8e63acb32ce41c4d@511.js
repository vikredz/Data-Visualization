function _1(md){return(
md`<h1 style="color: steelblue;">Assignment 2</h1>
`
)}

function _2(htl){return(
htl.html`<div id="info">
    <div class="left">
        <h1 id="name"> VIKRAMADITYA REDDY VARKALA </h1>
        <h2 id="id"> Z1973679 </h2>
    </div>
    <div class="right">
        <h2 id="title"> Data Visualization(CSCI 627) </h2>
        <h3 id="date"> 2023-09-27 </h3>
    </div>
</div>


<style>
  #info {
    display: flex;
    justify-content: space-between;
  }

  #name, #id {
    color: Steelblue;
  }

  #title, #date {
    color: Steelblue;
    font-style: italic;
    font-weight: normal;
  }

 .right {
    border: 2px solid Royalblue;
    margin: 10px;
    padding: 10px;
    border-radius: 10px;
    text-align: right;
  } 
</style>`
)}

function _3(md){return(
md`<h2>1. Table (25 pts)</h2>`
)}

function _data(d3){return(
d3.csv("https://gist.githubusercontent.com/dakoop/9e67814b6073ebbf6e7f55e31b5781ce/raw/5dad34b939d0d0789570064a75b145cc255f2811/newspaper-circulation.csv")
)}

function _5(md){return(
md`<h3>a. Data Processing  (10 pts)</h3>`
)}

function _filterData(data){return(
data.filter(d => d.Year !== "1940" && d.Weekday !== "--")
)}

function _processData(filterData){return(
filterData.map(d => ({ Year: parseInt(d.Year), Weekday: parseInt(d.Weekday),Sunday: parseInt(d.Sunday), Average:                                            (parseInt(d.Weekday) + parseInt(d.Sunday)) / 2}))
)}

function _8(md){return(
md`<h3>b. Table  (15 pts)</h3>`
)}

function _table(processData)
{ const table = document.createElement("table");
          const header = table.insertRow();
         
         //inserts header elements into row 
         header.insertCell().textContent = "Year";
         header.insertCell().textContent = "Weekday";
         header.insertCell().textContent = "Sunday";
         header.insertCell().textContent = "Average";
         
         //fill the processData into cells
         processData.forEach(d => { const fill = table.insertRow();
                                   fill.insertCell().textContent = d.Year;
                                   fill.insertCell().textContent = d.Weekday;
                                   fill.insertCell().textContent = d.Sunday;
                                   fill.insertCell().textContent = d.Average;
                                  });
         return table;
        }


function _10(md){return(
md`<h2>2. Horizontal Bar Chart (25 pts)</h2>`
)}

function _horizontalSvg()
{
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("width",300);
  svg.setAttribute("height",600);
  return svg;
}


function _horizontalGraph(processData,horizontalSvg)
{
    const max_avg = Math.max(...processData.map(d => d.Average)); //stores max averrage value
    const startYear = processData[0].Year; //stores year at index 0 position from processData
    const endYear = processData[processData.length - 1].Year; //stores year at last index position from processData
    //above 3 constants for labeling the graph
    
    const totalYears = endYear- startYear + 1;
    const x_dim = 240/max_avg;
    const y_dim = 560/totalYears;

   //year has all years from 1945 to 2020 including 2010
    //year_data has years that are common in between years and processData(it doesnt have year 2010)
    //i have used the years in year_data to plot average values
  
    for (let year = startYear; year <= endYear; year++) //increments year stating from starting year to ending year - (1)
    { 
        const i=year-startYear;  // To find index
        const year_data = processData.find(d =>d.Year===year); // looks for year in the processData and compares it with year in eq 1                                                                        above.
        
        // plot the bar If exists 
        if (year_data) 
        {
            const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
            rect.setAttribute("x","60"); //left some space for labels
            rect.setAttribute("y", y_dim*i); // finds position for bars
            rect.setAttribute("width", year_data.Average * x_dim);
            rect.setAttribute("height", y_dim-1);// Use the y_dim as the height
            rect.setAttribute("fill","gray");
            horizontalSvg.appendChild(rect);
        }

        // Print the label for starting year, ending year, and every decade
        //EXTRA CREDIT for labelling decade
        if (year === startYear || year === endYear || year % 10 === 0) 
        {
            const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
            text.setAttribute("x","30"); 
            text.setAttribute("y",y_dim * i + 7); 
            text.setAttribute("dominant-baseline", "middle");
            text.setAttribute("text-anchor","middle");//keeps text at middle
            text.textContent = year;
            horizontalSvg.appendChild(text);
        }
    }

      // Minimum average  label
    const minavg_label = document.createElementNS("http://www.w3.org/2000/svg", "text");
    minavg_label.setAttribute("x", 50);
    minavg_label.setAttribute("y", 580);
    minavg_label.setAttribute("text-anchor","start"); //keeps text at the end
    minavg_label.textContent = "0"; // i kept value as  0 as shown in the sample example in assignment 2.
    horizontalSvg.appendChild(minavg_label);

    // Maximum average label
    const maxavg_label = document.createElementNS("http://www.w3.org/2000/svg", "text");
    maxavg_label.setAttribute("x", 60 + max_avg * x_dim);
    maxavg_label.setAttribute("y", 580);
    maxavg_label.setAttribute("text-anchor","end"); //keeps text at the end
    maxavg_label.textContent = Math.round(max_avg/1000000) + " mil"; // rounding off max avg value by dividing by million(to keeop text                                                                           similar to sample example)
    horizontalSvg.appendChild(maxavg_label);
}


function _16(md){return(
md`<h2>3. Vertical Bar Chart (35 pts)</h2>`
)}

function _17(md){return(
md`<h3> a.Chart (20 pts) &  b.Interaction (15 pts)</h3>`
)}

function _decade(html){return(
html`<input type="range" id="decade" min="1940" max="2020" value="1940" step="10"></input>`
)}

function _verticalSvg()
{
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("width", 600);
  svg.setAttribute("height", 300);
  return svg;
}


function _verticalGraph(processData,decade,verticalSvg)
{

    const max_avg=Math.max(...processData.map(d => d.Average)); //stores max averrage value 
    const startYear = processData[0].Year; //stores year at index 0 position from processData
    const endYear = processData[processData.length-1].Year; //stores year at last index position from processData
    //above 3 constants for labeling the graph
    
    const padding = 2.2; // for the gap b/w each rect bar.
    const x_dim = 540/(endYear-startYear+1);
    const y_dim = 230/max_avg;
    const bar_dim = x_dim - padding;  // bar width

  
     //year has all years from 1945 to 2020 including 2010
     //year_data has years that are common in between years and processData(it doesnt have year 2010)
    //i have used the years in year_data to plot average values
  
    for (let year = startYear; year <= endYear; year++) //increments year stating from starting year to ending year - (1)
    {
      const i = year - startYear;  // To find index
      const year_data = processData.find(d => d.Year === year); // looks for year in the processData and compares it with year in eq 1                                                                        above.
      

        if (year_data)
        {
            const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
            rect.setAttribute("x", (x_dim * i) + padding/2 + 30);
            rect.setAttribute("y", 260 - (year_data.Average * y_dim)); 
            rect.setAttribute("width", bar_dim); 
            rect.setAttribute("height", year_data.Average * y_dim);
            rect.setAttribute("fill","gray");

          
          //interaction(hhighlight)
          //Math.floor(year_data.Year/10)*10 returns the starting point of a decade
          //year%10 modulues method can also be used here as the remainder with 0 will be the decade starting point.
          //if (year_data.Year-year_data.Year%10===decade-decade%10)
          
          if (Math.floor(year_data.Year/10)*10 === Math.floor(decade/10)*10) 
          {
            rect.setAttribute("class", "highlighted");
          } 
          
          verticalSvg.appendChild(rect);
          
        }

        ////EXTRA CREDIT for labelling decade
        // labels year ending with 0(decade) and start,end year.  
        if (year % 10 === 0 || year === startYear || year === endYear)  
        {
            const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
            text.setAttribute("x", x_dim*i+ 30); //finds postion for labeling text.
            text.setAttribute("y", 290);
            text.setAttribute("text-anchor", "middle"); //keeps the text in the middle
            text.textContent = year;
            verticalSvg.appendChild(text);
        }
    }

    // Mininum average label.
    const minavg_label = document.createElementNS("http://www.w3.org/2000/svg", "text");
    minavg_label.setAttribute("x", 10);
    minavg_label.setAttribute("y", 260);
    minavg_label.setAttribute("text-anchor", "end"); //keeps text at the end
    minavg_label.textContent = "0"; // i kept value as  0 as shown in the sample example in assignment 2.
    verticalSvg.appendChild(minavg_label);

    // Maximum average label
    const maxavg_label = document.createElementNS("http://www.w3.org/2000/svg", "text");
    maxavg_label.setAttribute("x",40);
    maxavg_label.setAttribute("y",30);
    maxavg_label.setAttribute("text-anchor","end");//keeps text at the end
    maxavg_label.textContent = Math.round(max_avg/1000000) + " mil"; // rounding off max avg value by dividing by million(to keeop text                                                                           similar to sample example)
    verticalSvg.appendChild(maxavg_label);
}


function _21(htl){return(
htl.html`<style> 
  .highlighted { 
    fill: khaki;
  }
</style>
<!-- selects highlighted class and fills it with colour -->`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["htl"], _2);
  main.variable(observer()).define(["md"], _3);
  main.variable(observer("data")).define("data", ["d3"], _data);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer("filterData")).define("filterData", ["data"], _filterData);
  main.variable(observer("processData")).define("processData", ["filterData"], _processData);
  main.variable(observer()).define(["md"], _8);
  main.variable(observer("table")).define("table", ["processData"], _table);
  main.variable(observer()).define(["md"], _10);
  main.variable(observer("horizontalSvg")).define("horizontalSvg", _horizontalSvg);
  main.variable(observer("horizontalGraph")).define("horizontalGraph", ["processData","horizontalSvg"], _horizontalGraph);
  main.variable(observer()).define(["md"], _16);
  main.variable(observer()).define(["md"], _17);
  main.variable(observer("viewof decade")).define("viewof decade", ["html"], _decade);
  main.variable(observer("decade")).define("decade", ["Generators", "viewof decade"], (G, _) => G.input(_));
  main.variable(observer("verticalSvg")).define("verticalSvg", _verticalSvg);
  main.variable(observer("verticalGraph")).define("verticalGraph", ["processData","decade","verticalSvg"], _verticalGraph);
  main.variable(observer()).define(["htl"], _21);
  return main;
}

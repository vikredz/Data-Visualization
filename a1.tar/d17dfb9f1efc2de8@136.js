function _1(md){return(
md`<h1 style="color: steelblue;">Assignment 1</h1>
`
)}

function _2(md){return(
md`<h3>1. Info (HTML & CSS) (15 pts)</h3>`
)}

function _3(htl){return(
htl.html`<div id="info">
    <div class="left">
        <h1 id="name"> VIKRAMADITYA REDDY VARKALA </h1>
        <h2 id="id"> Z1973679 </h2>
    </div>
    <div class="right">
        <h2 id="title"> Data Visualization(CSCI 627) </h2>
        <h3 id="date"> 2023-09-13 </h3>
    </div>
</div>


<style>
  #info {
    display: flex;
    justify-content: space-between;
  }

  #name, #id {
    color: Steelblue;
  }

  #title, #date {
    color: Steelblue;
    font-style: italic;
    font-weight: normal;
  }

 .right {
    border: 2px solid Royalblue;
    margin: 10px;
    padding: 10px;
    border-radius: 10px;
    text-align: right;
  } 
</style>`
)}

function _4(md){return(
md`<h3>2. Camera Phone (SVG & CSS) (20 pts)</h3>`
)}

function _5(htl){return(
htl.html`<svg id="camera" width="150" height="300">
    <!-- Phone Body -->
    <rect x="10" y="10" width="130" height="280" rx="20" ry="20" fill="lightsteelblue" stroke="darkslategray" stroke-opacity="0.5"/>

    <!-- Side Button -->
    <rect id="button" x="140" y="40" width="8" height="40"  fill="steelblue"/>

    <!-- Camera Region -->
    <rect x="20" y="20" width="60" height="60" rx="10" ry="10" fill="steelblue" fill-opacity="0.5" stroke="darkslategray"                      stroke-width="4" stroke-opacity="0.5"/>

    <!-- Lenses -->
    <circle cx="38" cy="38" r="12" fill="dimgray" stroke="darkslategray" stroke-width="2" />
    <circle cx="62" cy="62" r="12" fill="dimgray" stroke="darkslategray" stroke-width="2"/>

    <!-- Flash -->
    <circle id="flash" cx="65" cy="35" r="8" fill="khaki" />

    <!-- Logo -->
    <line x1="65" y1="140" x2="85" y2="160" stroke="ivory" stroke-width="5"/>
    <line x1="65" y1="160" x2="85" y2="140" stroke="ivory" stroke-width="5"/>
    <line x1="60" y1="166" x2="90" y2="166" stroke="ivory" stroke-width="1"/>
    <text x="65" y="175" font-family="Arial" font-size="6" fill="ivory">X-PRO</text>


</svg>
      

<style>
#button:hover ~ #flash {
  fill: white;
}
</style>

<!-- References For Color:https://johndecember.com/html/spec/colorsvg.html -->
<!-- Reference Hover:https://developer.mozilla.org/en-US/docs/Web/CSS/:hover -->
<!-- Reference https://developer.mozilla.org/en-US/docs/Web/CSS/General_sibling_combinator -->`
)}

function _6(md){return(
md`<h3>3. Bar Chart (Plot) (15 pts)</h3>`
)}

function _data(d3){return(
d3.csv("https://raw.githubusercontent.com/the-pudding/data/master/kidz-bop/KB_group-overiew.csv")
)}

function _8(Plot,data){return(
Plot.plot({
  marks: [
    Plot.barY(data, {x: "category", y: "pctCensored",fill: "#0047ab"})
  ]
})
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["htl"], _3);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer()).define(["htl"], _5);
  main.variable(observer()).define(["md"], _6);
  main.variable(observer("data")).define("data", ["d3"], _data);
  main.variable(observer()).define(["Plot","data"], _8);
  return main;
}

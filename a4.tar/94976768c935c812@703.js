function _1(md){return(
md`<h1 style="color: steelblue;">Assignment 4</h1>`
)}

function _2(htl){return(
htl.html`<div id="info">
    <div class="left">
        <h1 id="name"> VIKRAMADITYA REDDY VARKALA </h1>
        <h2 id="id"> Z1973679 </h2>
    </div>
    <div class="right">
        <h2 id="title"> Data Visualization(CSCI 627) </h2>
        <h3 id="date"> 2023-11-10 </h3>
    </div>
</div>


<style>
  #info {
    display: flex;
    justify-content: space-between;
  }

  #name, #id {
    color: Steelblue;
  }

  #title, #date {
    color: Steelblue;
    font-style: italic;
    font-weight: normal;
  }

 .right {
    border: 2px solid Royalblue;
    margin: 10px;
    padding: 10px;
    border-radius: 10px;
    text-align: right;
  } 
</style>`
)}

function _3(htl){return(
htl.html`<h2>1. Illinois Map (25 pts)</h2>`
)}

function _mapData(d3){return(
d3.json("https://gist.githubusercontent.com/dakoop/d06705a420fb348e7e03c7437bbfe4cb/raw/172303390752b7a224d876582043240ee9e9bd9b/il-counties.geojson")
)}

function _cropData(d3){return(
d3.json("https://gist.githubusercontent.com/dakoop/d06705a420fb348e7e03c7437bbfe4cb/raw/172303390752b7a224d876582043240ee9e9bd9b/il-crops.json")
)}

function _height(){return(
600
)}

function _width(){return(
900
)}

function _colorScale(d3){return(
d3.scaleOrdinal(d3.schemeCategory10)
)}

function _9(htl){return(
htl.html`<h2>a. Base Map (15 pts)</h2>`
)}

function _mapProjection(d3,width,height,mapData){return(
d3.geoTransverseMercator()
  .rotate([88 + 20 / 60, -36 - 40 / 60])
  .fitSize([width, height], mapData)
)}

function _path(d3,mapProjection){return(
d3.geoPath().projection(mapProjection)
)}

function _Basemap(d3,width,height,mapProjection,mapData)
{
  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height);

  const path = d3.geoPath().projection(mapProjection);
  
  const counties = svg.selectAll(".county")
    .data(mapData.features)
    .join("path")
      .attr("class", "county")
      .attr("d", path) 
      .attr("fill", "lightblue") 
      .attr("stroke", "black");

  //tooptip
  counties.append("title")
    .text(d => d.properties.COUNTY_NAM);

  return svg.node();
}


function _13(htl){return(
htl.html`<h2>b. Agricultural Regions (10 pts)</h2>`
)}

function _district(cropData){return(
cropData.reduce((lookup, d) => { 
  lookup[d["County ANSI"]] = d["Ag District"];
  return lookup;
}, {})
)}

function _AgriRegionMap(d3,width,height,mapProjection,mapData,district,colorScale)
{
  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height);


  const path = d3.geoPath().projection(mapProjection);

  const counties = svg.selectAll(".county")
    .data(mapData.features)
    .join("path")
      .attr("class", "county")
      .attr("d", path)
      .attr("fill", d => {
        const agDistrict = district[d.properties.CO_FIPS];
        return agDistrict ? colorScale(agDistrict) : 'grey';// in case of  missing data
      })
      .attr("stroke", "black");

  // tool tip to sjow county name and ag district name
  counties.append("title")
    .text(d => `County: ${d.properties.COUNTY_NAM} \n Ag District:${district[d.properties.CO_FIPS]}`);
  
  return svg.node();
}


function _16(htl){return(
htl.html`<h2>2. Crop Production by County (45 pts)</h2>`
)}

function _17(htl){return(
htl.html`<h2>a. 2022 Corn Harvested (15 pts)</h2>`
)}

function _harvestedData(cropData,selectedCrop,selectedYear)
{
  const map = new Map();
  
  cropData.forEach(d => { 
    const cropValue = d[selectedCrop] && d[selectedCrop][selectedYear];
  
    if (cropValue) 
    { 
      map.set(d["County ANSI"], cropValue);
    } else
    {
      map.set(d["County ANSI"], null);
    }
  });
  return map;
}


function _20(md){return(
md`Extra credit`
)}

function _selectedYear(Inputs){return(
Inputs.select([2002, 2012, 2022], {label: "Select Year"})
)}

function _selectedCrop(Inputs){return(
Inputs.select(['cornHarvested', 'soybeansHarvested'], {label: "Select Crop"})
)}

function _23(Plot,selectedYear,mapData,harvestedData){return(
Plot.plot({
  width: 600,
  height: 900,
  color: {
    scheme: "Greens",
    type: "linear",
    legend: true,
    label: `Harvested (${selectedYear})`,
    unknown: "#ccc"
  },
  
  marks: [
    Plot.geo(mapData, {
      fill: d => {
        const value = harvestedData.get(d.properties.CO_FIPS);
        return value
      },
      title: d => {
        const value = harvestedData.get(d.properties.CO_FIPS);
        return `County-${d.properties.COUNTY_NAM}: ${value != null ? value : "Data not available"}`;
      }
    }),
    Plot.geo(mapData, { stroke: "black", fill: "none" })
  ],
  
  x: { axis: null },
  y: { axis: null }
})
)}

function _24(md){return(
md`Reference : https://observablehq.com/@observablehq/build-your-first-choropleth-map-with-observable-plot`
)}

function _25(htl){return(
htl.html`<h2>b. 2022 % Corn Acres Harvested (15 pts)</h2>`
)}

function _cornHarvestedPercentMap(cropData){return(
new Map(
  cropData.filter(d => d['County ANSI'] !== null && d.cornHarvested['2022'] !== null && d['LAND AREA'] !== null)
    .map(d => [d['County ANSI'],(d.cornHarvested['2022'] / d['LAND AREA']) * 100 ])// Calculate the percentage
)
)}

function _27(Plot,mapData,cornHarvestedPercentMap){return(
Plot.plot({
  width: 600,
  height: 900,
  color: {
    scheme: "Blues",
    type: "linear",
    label: "% Corn Acres Harvested",
    legend: true,
    unknown: "#ccc"
  },
  marks: [
    Plot.geo(mapData, {
      fill: d => cornHarvestedPercentMap.get(d.properties.CO_FIPS),
      title: d => {
        const value = cornHarvestedPercentMap.get(d.properties.CO_FIPS);
        return `${d.properties.COUNTY_NAM}\n% Corn Harvested: ${value != null ? value : "Data not available"}%`;
      },
      stroke: "white"
    })
  ],

  //remove axes
  x: { axis: null }, 
  y: { axis: null }, 
})
)}

function _28(htl){return(
htl.html`<h2>c. 2022 Corn-Soybean Difference (15 pts)</h2>`
)}

function _cornsoyDiffData(cropData){return(
new Map(
  cropData.filter(d => d['County ANSI'] !== null && d.cornHarvested['2022'] !== null && d.soybeansHarvested['2022'] !== null && d['LAND AREA'] !== null)
    .map(d => {
      const difference = ((d.cornHarvested['2022'] - d.soybeansHarvested['2022']) / d['LAND AREA']) * 100;
      return [d['County ANSI'], difference];
    })
)
)}

function _30(Plot,mapData,cornsoyDiffData){return(
Plot.plot({
  width: 600,
  height: 900,
  color: 
  {
    type: "diverging", 
    scheme: "RdBu", 
    label: "Corn-Soybean Difference (%)",
    legend: true,
    unknown: "#ccc" // Color for counties without data
  },
  
  marks: [
    Plot.geo(mapData, {
  
      fill: d => {
        const value = cornsoyDiffData.get(d.properties.CO_FIPS);
        return value
      },
      title: d => {
        const value = cornsoyDiffData.get(d.properties.CO_FIPS);
        return `County: ${d.properties.COUNTY_NAM}\nCorn-Soybean Difference: ${typeof value === 'number' ? value : "Data not available"}%`;
      },
      stroke: "black"
    })
  ],
  x: { axis: null }, 
  y: { axis: null }, 
})
)}

function _31(htl){return(
htl.html`<h2>3.Corn Harvest Treemap (40 points)</h2>`
)}

function _treemapData(d3,cropData)
{
  const root = {
    name: "root",
    children: []
  };

  const dist = d3.group(cropData, d => d['Ag District']);

  for (const [district, entries] of dist) {
    const districtNode = {
      name: district,
      children: entries.map(entry => ({
        name: entry.County,
        value: entry.cornHarvested["2022"]
      }))
    };
    root.children.push(districtNode);
  }

  return root;
}


function _hierarchyRoot(d3,treemapData){return(
d3.hierarchy(treemapData).sum(d => d.value).sort((a, b) => b.value - a.value)
)}

function _treemap(d3,width,height,hierarchyRoot)
{
  const layout = d3.treemap()
    .size([width, height])
    .padding(1);

  layout(hierarchyRoot);
  return hierarchyRoot;
}


function _38(md){return(
md`Run Below cell for output`
)}

function _TreeMap(d3,width,height,hierarchyRoot,colorScale)
{
  const svg = d3.create("svg")
    .attr("viewBox", [0, 0, width, height])
    .style("font", "10px sans-serif");

  const leaf = svg.selectAll("g")
    .data(hierarchyRoot.leaves())
    .join("g")
      .attr("transform", d => `translate(${d.x0},${d.y0})`);

  const lrect = leaf.append("rect")
    .attr("fill", d => colorScale(d.parent.data.name))
    .attr("width", d => d.x1 - d.x0)
    .attr("height", d => d.y1 - d.y0);

  // Tooltip to show Ag Distict Coutnty and Value
  lrect.append("title")
    .text(d => `Ag District: ${d.parent.data.name}\nCounty: ${d.data.name}\nValue: ${d.data.value}`);
  //country label
  leaf.append("text")
    .attr("x", 3)
    .attr("y", 10)
    .text(d => d.data.name)
    .attr("font-size", "0.8em")
    .attr("fill", "white");

  const regionLabels = svg.selectAll("g.region")
    .data(hierarchyRoot.descendants().filter(d => d.depth === 1))
    .join("g")
      .attr("transform", d => `translate(${(d.x0 + d.x1) / 2},${(d.y0 + d.y1) / 2})`);
  
  //ag district label
  regionLabels.append("text")
    .attr("text-anchor", "middle")
    .text(d => d.data.name)
    .attr("fill", "white")
    .attr("font-size", "1.5em")
    .attr("font-weight", "bold");

  return svg.node();
}


function _40(md){return(
md`Reference:https://observablehq.com/@dakoop/treemap`
)}

function _41(htl){return(
htl.html`<h2>EXTRA CREDIT (upto 20 points)</h2>`
)}

function _42(md){return(
md`all students may implement a way for users to interactively update which year (or crop) is shown for the visualizations shown in **Part 2 or Part 3** (up to 20 points).`
)}

function _43(md){return(
md`=>I have implemented dropdown boxes that allows users to interactively update both  year and croptype in **part 2** of the assignment for extra credit`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["htl"], _2);
  main.variable(observer()).define(["htl"], _3);
  main.variable(observer("mapData")).define("mapData", ["d3"], _mapData);
  main.variable(observer("cropData")).define("cropData", ["d3"], _cropData);
  main.variable(observer("height")).define("height", _height);
  main.variable(observer("width")).define("width", _width);
  main.variable(observer("colorScale")).define("colorScale", ["d3"], _colorScale);
  main.variable(observer()).define(["htl"], _9);
  main.variable(observer("mapProjection")).define("mapProjection", ["d3","width","height","mapData"], _mapProjection);
  main.variable(observer("path")).define("path", ["d3","mapProjection"], _path);
  main.variable(observer("Basemap")).define("Basemap", ["d3","width","height","mapProjection","mapData"], _Basemap);
  main.variable(observer()).define(["htl"], _13);
  main.variable(observer("district")).define("district", ["cropData"], _district);
  main.variable(observer("AgriRegionMap")).define("AgriRegionMap", ["d3","width","height","mapProjection","mapData","district","colorScale"], _AgriRegionMap);
  main.variable(observer()).define(["htl"], _16);
  main.variable(observer()).define(["htl"], _17);
  main.variable(observer("harvestedData")).define("harvestedData", ["cropData","selectedCrop","selectedYear"], _harvestedData);
  main.variable(observer()).define(["md"], _20);
  main.variable(observer("viewof selectedYear")).define("viewof selectedYear", ["Inputs"], _selectedYear);
  main.variable(observer("selectedYear")).define("selectedYear", ["Generators", "viewof selectedYear"], (G, _) => G.input(_));
  main.variable(observer("viewof selectedCrop")).define("viewof selectedCrop", ["Inputs"], _selectedCrop);
  main.variable(observer("selectedCrop")).define("selectedCrop", ["Generators", "viewof selectedCrop"], (G, _) => G.input(_));
  main.variable(observer()).define(["Plot","selectedYear","mapData","harvestedData"], _23);
  main.variable(observer()).define(["md"], _24);
  main.variable(observer()).define(["htl"], _25);
  main.variable(observer("cornHarvestedPercentMap")).define("cornHarvestedPercentMap", ["cropData"], _cornHarvestedPercentMap);
  main.variable(observer()).define(["Plot","mapData","cornHarvestedPercentMap"], _27);
  main.variable(observer()).define(["htl"], _28);
  main.variable(observer("cornsoyDiffData")).define("cornsoyDiffData", ["cropData"], _cornsoyDiffData);
  main.variable(observer()).define(["Plot","mapData","cornsoyDiffData"], _30);
  main.variable(observer()).define(["htl"], _31);
  main.variable(observer("treemapData")).define("treemapData", ["d3","cropData"], _treemapData);
  main.variable(observer("hierarchyRoot")).define("hierarchyRoot", ["d3","treemapData"], _hierarchyRoot);
  main.variable(observer("treemap")).define("treemap", ["d3","width","height","hierarchyRoot"], _treemap);
  main.variable(observer()).define(["md"], _38);
  main.variable(observer("TreeMap")).define("TreeMap", ["d3","width","height","hierarchyRoot","colorScale"], _TreeMap);
  main.variable(observer()).define(["md"], _40);
  main.variable(observer()).define(["htl"], _41);
  main.variable(observer()).define(["md"], _42);
  main.variable(observer()).define(["md"], _43);
  return main;
}

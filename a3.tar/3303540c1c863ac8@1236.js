import define1 from "./a33468b95d0b15b0@817.js";

function _1(md){return(
md`<h1 style="color: steelblue;">Assignment 3</h1>
`
)}

function _2(md){return(
md`<div id="info">
    <div class="left">
        <h1 id="name"> VIKRAMADITYA REDDY VARKALA </h1>
        <h2 id="id"> Z1973679 </h2>
    </div>
    <div class="right">
        <h2 id="title"> Data Visualization(CSCI 627) </h2>
        <h3 id="date"> 2023-10-11 </h3>
    </div>
</div>


<style>
  #info {
    display: flex;
    justify-content: space-between;
  }

  #name, #id {
    color: Steelblue;
  }

  #title, #date {
    color: Steelblue;
    font-style: italic;
    font-weight: normal;
  }

 .right {
    border: 2px solid Royalblue;
    margin: 10px;
    padding: 10px;
    border-radius: 10px;
    text-align: right;
  } 
</style>`
)}

function _3(htl){return(
htl.html`<h2>1. Tableau (25 points)</h2>`
)}

function _4(md){return(
md`# <h4 style="color: steelblue;">LINK TO BAR CHART :</h4> https://public.tableau.com/views/A3_Part1_Tableau/Sheet1?:language=en-US&:display_count=n&:origin=viz_share_link`
)}

function _sheet12(FileAttachment){return(
FileAttachment("Sheet 1@2.png").image()
)}

function _6(htl){return(
htl.html`<h2>2. Observable Plot (30 points)</h2>`
)}

function _7(md){return(
md`**NOTE: Please run plot.plot code which is below STACKED BAR CHART in part2 (if the stacked bargraph is not in order) while grading**`
)}

function _data(d3){return(
d3.csv("https://gist.githubusercontent.com/dakoop/78efac022b7fa30cab8bf261285c432a/raw/f70dedfa4ab43f8b429056efc63da8a2efded82a/chicago-traffic-crashes-2022.csv",d3.autoType)
)}

function _monthFormat(d3){return(
d3.timeFormat("%b %Y")
)}

function _groupData(d3,data,monthFormat){return(
d3.groups(data, d => monthFormat(new Date(d.CRASH_DATE)), d => d.FIRST_CRASH_TYPE)
)}

function _11(groupData){return(
groupData.reverse()
)}

function _plotData(groupData)
{
  const output = [];
groupData.forEach(([date, crashGroups]) => {
    crashGroups.forEach(([crashType, entries]) => {
        const totalCount = entries.length;
        output.push({
            date: date,
            type: crashType,
            count: totalCount
        });
    });
});
return output;
}


function _crashes(crashesForStack){return(
Object.keys(crashesForStack[0]).filter(d => d !== 'Total' && d !== 'Date')
)}

function _14(plotData,crashes){return(
plotData.sort((a, b) => crashes.indexOf(a.type) - crashes.indexOf(b.type))
)}

function _15(Plot,plotData){return(
Plot.plot({
  marginBottom: 60,
  width: 900,
  height: 600,
  x: { label: "Crash Date" ,tickRotate: -90},
  y: { tickFormat: "s", tickSpacing: 40 , label:"Count of First Crash Type"},
  color: { legend: true, label: "First Crash Type" },
  marks: [
    Plot.barY(plotData, {
      x: "date",
      y: "count",
      fill: "type", 

      sort: {x: null,reverse: true}
      

    })
  ]
})
)}

function _16(md){return(
md`References:1) https://observablehq.com/@observablehq/plot-stacked-bar-chart
2)https://observablehq.com/plot/features/legends?collection=%40observablehq%2Fplot`
)}

function _17(htl){return(
htl.html`<h2>3. D3 (30/45 points)</h2>`
)}

function _crashesMonthType(d3,data){return(
d3.rollup(data, v => v.length, d => d.CRASH_DATE.getMonth(), d => d.FIRST_CRASH_TYPE)
)}

function _crashesForStack(crashesMonthType,d3){return(
[...crashesMonthType.entries()].map(d => ({...Object.fromEntries([...d[1].entries()]), "Total": d3.sum(d[1].values()), "Date": d[0]}))
)}

function _20(crashesForStack){return(
crashesForStack.reverse()
)}

function _stack(d3,data){return(
d3.stack()
  .keys(data.columns.slice(0, -2))
)}

function _series(stack,crashesForStack){return(
stack(crashesForStack)
)}

function _height(){return(
400
)}

function _width(){return(
800
)}

function _26(Swatches,d3,crashes){return(
Swatches(d3.scaleOrdinal(crashes, d3.schemeTableau10), {
  columns: "180px"
})
)}

function _27(d3,width,height,crashes,crashesForStack)
{
  const margin = {top: 20, bottom: 20, left: 80, right: 10};

  const svgElt = d3.create("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom);

  const svg = svgElt.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top})`);
  

  // Stacks data
  const stack = d3.stack()
    .keys(crashes)//from part 2 of assignment.
  const series = stack(crashesForStack);
  const monthNames = crashesForStack.map(d => d3.timeFormat("%b %Y")(new Date(2022, d.Date)));
  

  //scale
  const xScale = d3.scaleBand()
    .domain(monthNames)
    .range([0, width])
    .padding(0.2);

  const yScale = d3.scaleLinear()
    .domain([0, d3.max(series, d => d3.max(d, d => d[1]))])
    .range([height, 0]);
  
  

  // axes
  const xAxis = d3.axisBottom(xScale);
  svg.append("g")
    .attr("transform", `translate(0,${height})`)
    .call(xAxis);

  const yAxis = d3.axisLeft(yScale);
  svg.append("g").call(yAxis);
  
  
  // stacked bar colour.
  const color = d3.scaleOrdinal()
    .domain(crashes)
    .range(d3.schemeTableau10);

  svg.append("g")

  .selectAll("g")
  .data(series)
  
  .enter()
  .append("g")
    .attr("fill", d => color(d.key))

  .selectAll("rect")
  .data(d => d)
  
  .enter()
  .append("rect")
    .attr("x", (d, i) => xScale(monthNames[i]))
    .attr("y", d => yScale(d[1]))
    .attr("height", d => yScale(d[0]) - yScale(d[1]))
    .attr("width", xScale.bandwidth());

 return svgElt.node();
}


function _28(md){return(
md`References: 
1)d3 lecture observable notebook on (09/25) : cell 146
2)https://observablehq.com/@thetylerwolf/day-9-stacked-bar-chart

i have done legend in a seperate cell as showm in the example in this notebook
3)https://observablehq.com/@d3/color-legend

            `
)}

function _29(htl){return(
htl.html`<h2>EXTRA CREDIT:</h2>`
)}

function _30(htl){return(
htl.html`<h3> Stacked Bar Chart using Vega-Lite.</h3>`
)}

function _31(md){return(
md`# <h4 style="color: steelblue;">LINK TO BAR CHART :</h4> https://vega.github.io/editor/#/url/vega-lite/N4IgJAzgxgFgpgWwIYgFwhgF0wBwqgegIDc4BzJAOjIEtMYBXAI0poHsDp5kTykBaADZ04JAKyUAVhDYA7EABoQAEySYUqUAwBOgtBmx5CBWhEzU6jJgwhxtUOZjizzDhAVUBrNmxwEA7AAccABmSFAADABMUUz+YQDMEVBITIFMIVEAbACMUYFiUAAsCVFIBNpIAO4EIf4RynDKYUWpJSHpRVEAnBFiWaFQWQmqgUhRoY3KgWUEsDQpZGz8mJUhIQv8UJUQ8BD8UdFRlFAQxCAAvkrI2p76TEjaiiDODso0smRooAAe3yCYGgIOAAVVkdH0CEcMGeGzggmU+gAwgAlACCAGUABIAfQAImiACoAUWemAAnjg4Po2Np3rIkHolIDMIJqegkTsYAACACy0MuSnJ-yQZDI2j4Tn0DgYLjJlPZIAAjgwkC46GoaKQyXQ2ci2LLMNy2CFuQAxGjaMzczlIXbcwkKwUgByCWn-OEI-RmgCSKIxhJxqMxuMJAE0AAqk5lO9CyNgID6M57QRns0DKBNID5oADaIAjaJRAGliXi+QB5QkVlHcgBqxKxPqRABloyAUcSi9ziQA5PHPDE+vHEjEAdR9UeehJBKN7Pt7AHFnmil23nlG8QQkWHWz6A88q1jibWG03W8SbRWWy39z6K73D4TjyiQABdJSVT7s-MAYjg-gPGIUTPL+UD+OB4GgUgcDgXAgSgTkdSAUUoHdEUWSAYiSi-ma3Q5AAQhEOSgQkYg5DkZpIqBxF4RE1FvlcAK6oqFpWkatr2hSVKXExLJ6hyMALKKbAOmsGxQDaXJwBA3KHDElxAA`
)}

function _visualization(FileAttachment){return(
FileAttachment("visualization.png").image()
)}

function _33(md){return(
md`Reference: https://vega.github.io/vega-lite/examples/stacked_bar_weather.html`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["Sheet 1@2.png", {url: new URL("./files/f2751358bcf339e8a8cf48669bd92f16b475257f2e700a1c1203ce263e9533ff8350826a6394dc9db361e02262e118708df697e6370842316ebff8d3fb56a7ae.png", import.meta.url), mimeType: "image/png", toString}],
    ["visualization.png", {url: new URL("./files/575f1b14c96cb9aa3f56e0bcdc477a097afb0524615d8059b1a2b14e7850849b13131597bc4a06fb953edfda93fe07c453cdbe0cd7cc30c83ab918734338ed64.png", import.meta.url), mimeType: "image/png", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["htl"], _3);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer("sheet12")).define("sheet12", ["FileAttachment"], _sheet12);
  main.variable(observer()).define(["htl"], _6);
  main.variable(observer()).define(["md"], _7);
  main.variable(observer("data")).define("data", ["d3"], _data);
  main.variable(observer("monthFormat")).define("monthFormat", ["d3"], _monthFormat);
  main.variable(observer("groupData")).define("groupData", ["d3","data","monthFormat"], _groupData);
  main.variable(observer()).define(["groupData"], _11);
  main.variable(observer("plotData")).define("plotData", ["groupData"], _plotData);
  main.variable(observer("crashes")).define("crashes", ["crashesForStack"], _crashes);
  main.variable(observer()).define(["plotData","crashes"], _14);
  main.variable(observer()).define(["Plot","plotData"], _15);
  main.variable(observer()).define(["md"], _16);
  main.variable(observer()).define(["htl"], _17);
  main.variable(observer("crashesMonthType")).define("crashesMonthType", ["d3","data"], _crashesMonthType);
  main.variable(observer("crashesForStack")).define("crashesForStack", ["crashesMonthType","d3"], _crashesForStack);
  main.variable(observer()).define(["crashesForStack"], _20);
  main.variable(observer("stack")).define("stack", ["d3","data"], _stack);
  main.variable(observer("series")).define("series", ["stack","crashesForStack"], _series);
  main.variable(observer("height")).define("height", _height);
  main.variable(observer("width")).define("width", _width);
  const child1 = runtime.module(define1);
  main.import("Swatches", child1);
  main.variable(observer()).define(["Swatches","d3","crashes"], _26);
  main.variable(observer()).define(["d3","width","height","crashes","crashesForStack"], _27);
  main.variable(observer()).define(["md"], _28);
  main.variable(observer()).define(["htl"], _29);
  main.variable(observer()).define(["htl"], _30);
  main.variable(observer()).define(["md"], _31);
  main.variable(observer("visualization")).define("visualization", ["FileAttachment"], _visualization);
  main.variable(observer()).define(["md"], _33);
  return main;
}

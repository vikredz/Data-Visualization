import define1 from "./b2bbebd2f186ed03@1816.js";

function _1(md){return(
md`<h1 style="color: steelblue;">Assignment 5</h1>`
)}

function _2(htl){return(
htl.html`<div id="info">
    <div class="left">
        <h1 id="name"> VIKRAMADITYA REDDY VARKALA </h1>
        <h2 id="id"> Z1973679 </h2>
    </div>
    <div class="right">
        <h2 id="title"> Data Visualization(CSCI 627) </h2>
        <h3 id="date"> 2023-12-06 </h3>
    </div>
</div>


<style>
  #info {
    display: flex;
    justify-content: space-between;
  }

  #name, #id {
    color: Steelblue;
  }

  #title, #date {
    color: Steelblue;
    font-style: italic;
    font-weight: normal;
  }

 .right {
    border: 2px solid Royalblue;
    margin: 10px;
    padding: 10px;
    border-radius: 10px;
    text-align: right;
  } 
</style>`
)}

function _counties(d3){return(
d3.json('https://gist.githubusercontent.com/dakoop/d06705a420fb348e7e03c7437bbfe4cb/raw/172303390752b7a224d876582043240ee9e9bd9b/il-counties.geojson')
)}

function _ilCrops(d3){return(
d3.json('https://gist.githubusercontent.com/dakoop/d06705a420fb348e7e03c7437bbfe4cb/raw/172303390752b7a224d876582043240ee9e9bd9b/il-crops.json')
)}

function _ilCropsMap(ilCrops){return(
new Map(ilCrops.map(d => [d['County ANSI'],d]))
)}

function _6(htl){return(
htl.html`<h2>1. Filtering (30 pts)</h2>`
)}

function _soybeanPercentage(){return(
function soybeanPercentage(cdata) 
{
  if (!cdata || !cdata['LAND AREA'] || !cdata.soybeansPlanted['2022']) 
  {
    return NaN;
  }
  return (cdata.soybeansPlanted['2022']/cdata['LAND AREA']) * 100;
}
)}

function _cornPercentage(){return(
function cornPercentage(cdata) 
{
  if (!cdata||!cdata['LAND AREA']||!cdata.cornPlanted['2022']) 
  {
    return 0;
  }
  return (cdata.cornPlanted['2022']/cdata['LAND AREA']) * 100;
}
)}

function _maxCornPercentage(counties,ilCropsMap,cornPercentage){return(
Math.max(...counties.features.map(d => {
  const cdata = ilCropsMap.get(d.properties.CO_FIPS);
  return cornPercentage(cdata);
}))
)}

function _soybeanRange(interval){return(
interval([0,100], {
  step: 1,
  value: [0, 100],
  label: '% Soybean'
})
)}

function _12(Plot,counties,maxCornPercentage,ilCropsMap,soybeanPercentage,soybeanRange,cornPercentage){return(
Plot.plot({
  projection: {
    type: "transverse-mercator",
    rotate: [88 + 20 / 60, -36 - 40 / 60],
    domain: counties
  },
  width: 500,
  color: {
    label: "% Area Planted with Corn",
    scheme: "Viridis",
    unknown: "lightgray", //for counties outside of range
    legend: true,
    domain: [0, maxCornPercentage]
  },
  marks: [
    Plot.geo(counties.features, {
      fill: d => 
      {
        const cdata = ilCropsMap.get(d.properties.CO_FIPS);
        const soybeanPerc = soybeanPercentage(cdata);
        return soybeanPerc >= soybeanRange[0]&&soybeanPerc <= soybeanRange[1] ? cornPercentage(cdata) :"lightgray";
      }
    }),
  ],
})
)}

function _13(htl){return(
htl.html`<h2>2. Brushing (40 pts)</h2>`
)}

function _14(htl){return(
htl.html`<h2>a. One-to-One Highlighting (20 pts)</h2>`
)}

function _farmedMap(Plot,counties,ilCropsMap){return(
Plot.plot({
  className: "farmedMap",
  projection: {
    type: "transverse-mercator",
    rotate: [88 + 20 / 60, -36 - 40 / 60],
    domain: counties
  },
  width: 500,
  color: {
    label: "% Area Planted with Corn or Soybeans",
    scheme: "viridis",
    unknown: "lightgray",
    legend: true
  },
  marks: [
    Plot.geo(counties.features, { fill: d => ((ilCropsMap.get(d.properties.CO_FIPS).cornPlanted['2022'] ?? NaN) + (ilCropsMap.get(d.properties.CO_FIPS).soybeansPlanted['2022'] ?? NaN)) / ilCropsMap.get(d.properties.CO_FIPS)['LAND AREA'] }),
  ],
})
)}

function _cropScatter(Plot,counties,ilCropsMap){return(
Plot.plot({
  className: "cropScatter",
  marginLeft: 60,
  width: 600,
  marks: [
    Plot.dot(counties.features, { x: d => (ilCropsMap.get(d.properties.CO_FIPS).cornPlanted['2022'] ?? NaN), y: d => (ilCropsMap.get(d.properties.CO_FIPS).soybeansPlanted['2022'] ?? NaN), fill: "blue", r: 4}),
  ],
})
)}

function _17(html,farmedMap,cropScatter){return(
html`<style>
#corn-soy-compare {
  display: flex;
}
</style>
<div id="corn-soy-compare">
  ${farmedMap}
  ${cropScatter}
</div>`
)}

function _18(d3,farmedMap,cropScatter)
{
  
  const counties = d3.select(farmedMap).selectAll("path");
  const points = d3.select(cropScatter).selectAll("circle");

  // Map highlihting
  counties.on("pointerover", function(event, d) {
    counties.classed("highlight", false);
    points.classed("highlight", false);

    d3.select(event.currentTarget).classed("highlight", true);
    points.filter(dd => dd === d).classed("highlight", true);})
    .on("pointerout", function() 
        {
          counties.classed("highlight", false);
          points.classed("highlight", false);
        });

  // Scatter points highlighting
  points.on("pointerover", function(event, d) {
    counties.classed("highlight", false);
    points.classed("highlight", false);

    d3.select(event.currentTarget).classed("highlight", true).raise();
    counties.filter(dd => dd === d).classed("highlight", true);})
    .on("pointerout", function() 
        {
          counties.classed("highlight", false);
          points.classed("highlight", false);
        });
}


function _19(htl){return(
htl.html`<h2>b. Region Highlighting (20 pts)</h2>`
)}

function _regionMap(Plot,counties,ilCropsMap){return(
Plot.plot({
  className: "regionMap",
  projection: {
    type: "transverse-mercator",
    rotate: [88 + 20 / 60, -36 - 40 / 60],
    domain: counties
  },
  width: 500,
  color: {
    label: "Agricultural District",
    scheme: "Tableau10",
    legend: true
  },
  marks: [
    Plot.geo(counties.features, { fill: d => ilCropsMap.get(d.properties.CO_FIPS)['Ag District'] }),
  ],
})
)}

function _cropScatter2(Plot,counties,ilCropsMap){return(
Plot.plot({
  className: "cropScatter2",
  marginLeft: 60,
  height:600,
  width: 800,
  marks: [
    Plot.dot(counties.features, { x: d => (ilCropsMap.get(d.properties.CO_FIPS).cornPlanted['2022'] ?? NaN), y: d => (ilCropsMap.get(d.properties.CO_FIPS).soybeansPlanted['2022'] ?? NaN), fill: "blue", r: 4}),
  ],
})
)}

function _22(html,regionMap,cropScatter2){return(
html`<style>
#corn-soy-region {
  display: flex;
}
</style>
<div id="corn-soy-region">
  ${regionMap}
  ${cropScatter2}
</div>`
)}

function _AgDistMap(counties,ilCropsMap){return(
Object.fromEntries(counties.features.map((county) => [county.properties.CO_FIPS,ilCropsMap.get(county.properties.CO_FIPS)["Ag District"]]))
)}

function _24(d3,regionMap,cropScatter2,AgDistMap,counties)
{
const AgRegions = d3.select(regionMap).selectAll("path");
const ScatterPoints = d3.select(cropScatter2).selectAll("circle");

// fucntion for district highlight
function regionHighlight(agDistrict) {
  AgRegions.classed("highlight", (d) => agDistrict === AgDistMap[counties.features[d].properties.CO_FIPS]);
  ScatterPoints .classed("highlight", (d) => agDistrict === AgDistMap[counties.features[d].properties.CO_FIPS]);
}

//pointer on
function mouseOn(event, d) {
  const id = counties.features[d].properties.CO_FIPS;
  const agDistrict = AgDistMap[id];
  regionHighlight(agDistrict);
}

//pointer out
function mouseOut() {
  AgRegions.classed("highlight", false);
 ScatterPoints.classed("highlight", false);
}
AgRegions.on("pointerover", mouseOn);
AgRegions.on("pointerout", mouseOut);
}


function _25(htl){return(
htl.html`<style>
.highlight{
  stroke: red;
  stroke-width: 2px;
  fill:red;
  fill-opacity:0.4
}
</style>

<!-- i have used same styling for both part 2a and 2b and part 3 -->`
)}

function _26(htl){return(
htl.html`<h2>3. Binned Scatterplot (30 pts)</h2>`
)}

function _farmedMap2(Plot,counties,ilCropsMap){return(
Plot.plot({
  className: "farmedMap",
  projection: {
    type: "transverse-mercator",
    rotate: [88 + 20 / 60, -36 - 40 / 60],
    domain: counties
  },
  width: 500,
  color: {
    label: "% Area Planted with Corn or Soybeans",
    scheme: "viridis",
    unknown: "lightgray",
    legend: true
  },
  marks: [
    Plot.geo(counties.features, { fill: d => ((ilCropsMap.get(d.properties.CO_FIPS).cornPlanted['2022'] ?? NaN) + (ilCropsMap.get(d.properties.CO_FIPS).soybeansPlanted['2022'] ?? NaN)) / ilCropsMap.get(d.properties.CO_FIPS)['LAND AREA'] }),
  ],
})
)}

function _CropBinned(Plot,counties,ilCropsMap){return(
Plot.plot({
className: "cropBinned", marginLeft: 90, width: 700,
color: {
scheme: "Inferno",
legend:true,
},
marks: [
Plot.rect(counties. features,
          Plot.bin({fill: "count"}, 
        {
          x: d => (ilCropsMap.get(d.properties.CO_FIPS) .cornPlanted ['2022'] ?? NaN),
          y: d => (ilCropsMap.get (d.properties.CO_FIPS) .soybeansPlanted['2022'] ?? NaN), fill: "", r: 4})),
  ],
})
)}

function _29(md){return(
md`Reference : https://observablehq.com/plot/transforms/bin`
)}

function _30(html,farmedMap2,CropBinned){return(
html`<style>
#corn-soy-compare-bin {
  display: flex;
}
</style>
<div id="corn-soy-compare-bin">
  ${farmedMap2}
  ${CropBinned}
</div>`
)}

function _binnedData(Plot,counties,ilCropsMap){return(
Plot.rect(counties.features,Plot.bin({fill: "count"}, {
  x: d => (ilCropsMap.get(d.properties.CO_FIPS).cornPlanted['2022'] ?? NaN),
  y: d => (ilCropsMap.get(d.properties.CO_FIPS).soybeansPlanted['2022'] ?? NaN),
  fill: "blue", r: 4
})).initialize()["data"]
)}

function _32(md){return(
md`Reference: https://talk.observablehq.com/t/how-to-get-the-bin-values-from-a-plot/8090/6`
)}

function _33(d3,farmedMap2,CropBinned,binnedData,counties)
{
  const countyMap = d3.select(farmedMap2).selectAll("path");
  const scatterplotBins = d3.select(CropBinned).selectAll("rect");

  scatterplotBins.on("pointerover", (event, id) => {
    d3.select(event.currentTarget).classed("highlight", true);

    const binHighlight = binnedData[id];
    const countyHighlight = binHighlight.map((d) => d.properties.CO_FIPS);

    countyMap
      .filter((dd) => {return countyHighlight.includes(counties.features[dd].properties["CO_FIPS"]);})
      .classed("highlight", true);
  });
  
  scatterplotBins.on("pointerout", (event, d) => {
    scatterplotBins.classed("highlight", false);
    countyMap.classed("highlight", false);
  });
}


function _34(md){return(
md`<h2 style="color: steelblue;">EXTRA CREDIT</h2>`
)}

function _35(md){return(
md`<h2>**select multiple counties in Part 2a** </h2>`
)}

function _farmedMapextra(Plot,counties,ilCropsMap){return(
Plot.plot({
  className: "farmedMap",
  projection: {
    type: "transverse-mercator",
    rotate: [88 + 20 / 60, -36 - 40 / 60],
    domain: counties
  },
  width: 500,
  color: {
    label: "% Area Planted with Corn or Soybeans",
    scheme: "viridis",
    unknown: "lightgray",
    legend: true
  },
  marks: [
    Plot.geo(counties.features, { fill: d => ((ilCropsMap.get(d.properties.CO_FIPS).cornPlanted['2022'] ?? NaN) + (ilCropsMap.get(d.properties.CO_FIPS).soybeansPlanted['2022'] ?? NaN)) / ilCropsMap.get(d.properties.CO_FIPS)['LAND AREA'] }),
  ],
})
)}

function _cropScatterextra(Plot,counties,ilCropsMap){return(
Plot.plot({
  className: "cropScatter",
  marginLeft: 60,
  width: 600,
  marks: [
    Plot.dot(counties.features, { x: d => (ilCropsMap.get(d.properties.CO_FIPS).cornPlanted['2022'] ?? NaN), y: d => (ilCropsMap.get(d.properties.CO_FIPS).soybeansPlanted['2022'] ?? NaN), fill: "blue", r: 4}),
  ],
})
)}

function _38(html,farmedMapextra,cropScatterextra){return(
html`<style>
#corn-soy-compare {
  display: flex;
}
</style>
<div id="corn-soy-compare">
  ${farmedMapextra}
  ${cropScatterextra}
</div>`
)}

function _39(md){return(
md`Click in counties for multiple selections. click again to deselect`
)}

function _40(d3,farmedMapextra,cropScatterextra)
{
  const counties = d3.select(farmedMapextra).selectAll("path");
  const points = d3.select(cropScatterextra).selectAll("circle");

  // Function to county selection
  function countyselection(element, data) {
    const click = d3.select(element).classed("selected");
    d3.select(element).classed("selected", !click);

    
    points.filter(dd => dd === data).classed("selected", !click);
    counties.filter(dd => dd === data).classed("selected", !click);
  }

  // For selecting/deselecting counties
  counties.on("click", function(event, d) {
    countyselection(event.currentTarget, d);
  });
  
  // For selecting/deselecting scatterplot points
  points.on("click", function(event, d) {
    countyselection(event.currentTarget, d);
  });
}


function _41(htl){return(
htl.html`<style>
  .selected {
  stroke: red;
  stroke-width: 2px;
  fill:red;
  fill-opacity:0.4
}
</style>`
)}

function _42(md){return(
md`<h2>Hexbin Scatterplot</h2>`
)}

function _d3(require){return(
require("d3@7", "d3-hexbin@0.2")
)}

function _CropHexBinned(Plot,counties,ilCropsMap){return(
Plot.plot({
  width: 500,
  height: 500,
  marginLeft: 60,
  inset: 10,
  x: { label: "Corn Planted (Acres)", type: "linear" },
  y: { label: "Soybeans Planted (Acres)", type: "linear" },
  color: { scheme: "Viridis", legend: true }, 
  
  marks: [
    Plot.hexagon(
      counties.features.map(d => ({ 
        cornPlanted: ilCropsMap.get(d.properties.CO_FIPS).cornPlanted['2022'] ?? NaN,
        soybeansPlanted: ilCropsMap.get(d.properties.CO_FIPS).soybeansPlanted['2022'] ?? NaN
      })),
      Plot.hexbin(
        { fill: "count" },
        {
          binWidth: 30,
          x: d => d.cornPlanted,
          y: d => d.soybeansPlanted,
          stroke: "white",
          strokeWidth: 0.75
        }
      )
    )
  ],
})
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["htl"], _2);
  main.variable(observer("counties")).define("counties", ["d3"], _counties);
  main.variable(observer("ilCrops")).define("ilCrops", ["d3"], _ilCrops);
  main.variable(observer("ilCropsMap")).define("ilCropsMap", ["ilCrops"], _ilCropsMap);
  main.variable(observer()).define(["htl"], _6);
  const child1 = runtime.module(define1);
  main.import("interval", child1);
  main.variable(observer("soybeanPercentage")).define("soybeanPercentage", _soybeanPercentage);
  main.variable(observer("cornPercentage")).define("cornPercentage", _cornPercentage);
  main.variable(observer("maxCornPercentage")).define("maxCornPercentage", ["counties","ilCropsMap","cornPercentage"], _maxCornPercentage);
  main.variable(observer("viewof soybeanRange")).define("viewof soybeanRange", ["interval"], _soybeanRange);
  main.variable(observer("soybeanRange")).define("soybeanRange", ["Generators", "viewof soybeanRange"], (G, _) => G.input(_));
  main.variable(observer()).define(["Plot","counties","maxCornPercentage","ilCropsMap","soybeanPercentage","soybeanRange","cornPercentage"], _12);
  main.variable(observer()).define(["htl"], _13);
  main.variable(observer()).define(["htl"], _14);
  main.variable(observer("farmedMap")).define("farmedMap", ["Plot","counties","ilCropsMap"], _farmedMap);
  main.variable(observer("cropScatter")).define("cropScatter", ["Plot","counties","ilCropsMap"], _cropScatter);
  main.variable(observer()).define(["html","farmedMap","cropScatter"], _17);
  main.variable(observer()).define(["d3","farmedMap","cropScatter"], _18);
  main.variable(observer()).define(["htl"], _19);
  main.variable(observer("regionMap")).define("regionMap", ["Plot","counties","ilCropsMap"], _regionMap);
  main.variable(observer("cropScatter2")).define("cropScatter2", ["Plot","counties","ilCropsMap"], _cropScatter2);
  main.variable(observer()).define(["html","regionMap","cropScatter2"], _22);
  main.variable(observer("AgDistMap")).define("AgDistMap", ["counties","ilCropsMap"], _AgDistMap);
  main.variable(observer()).define(["d3","regionMap","cropScatter2","AgDistMap","counties"], _24);
  main.variable(observer()).define(["htl"], _25);
  main.variable(observer()).define(["htl"], _26);
  main.variable(observer("farmedMap2")).define("farmedMap2", ["Plot","counties","ilCropsMap"], _farmedMap2);
  main.variable(observer("CropBinned")).define("CropBinned", ["Plot","counties","ilCropsMap"], _CropBinned);
  main.variable(observer()).define(["md"], _29);
  main.variable(observer()).define(["html","farmedMap2","CropBinned"], _30);
  main.variable(observer("binnedData")).define("binnedData", ["Plot","counties","ilCropsMap"], _binnedData);
  main.variable(observer()).define(["md"], _32);
  main.variable(observer()).define(["d3","farmedMap2","CropBinned","binnedData","counties"], _33);
  main.variable(observer()).define(["md"], _34);
  main.variable(observer()).define(["md"], _35);
  main.variable(observer("farmedMapextra")).define("farmedMapextra", ["Plot","counties","ilCropsMap"], _farmedMapextra);
  main.variable(observer("cropScatterextra")).define("cropScatterextra", ["Plot","counties","ilCropsMap"], _cropScatterextra);
  main.variable(observer()).define(["html","farmedMapextra","cropScatterextra"], _38);
  main.variable(observer()).define(["md"], _39);
  main.variable(observer()).define(["d3","farmedMapextra","cropScatterextra"], _40);
  main.variable(observer()).define(["htl"], _41);
  main.variable(observer()).define(["md"], _42);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer("CropHexBinned")).define("CropHexBinned", ["Plot","counties","ilCropsMap"], _CropHexBinned);
  return main;
}
